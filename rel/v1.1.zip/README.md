# Theme Switcher

## What it does

Provides a popup that allows you to see the themes and switch between them.

## What it shows

Demonstrates using the management API.

The "star-half.svg" icon is taken from the Material Core iconset and is used under the terms of its license: https://www.iconfinder.com/iconsets/material-core.
